import { createEvent, fireEvent, render, screen } from "@testing-library/react";
import React from "react";

import ConfirmationButton from "./ConfirmationButton";
import Icon, { ICONS } from "../Icon";
import userEvent from "@testing-library/user-event";

describe("ConfirmationButton ", () => {
  it("shows button icon and label", () => {
    render(
      <ConfirmationButton
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm: jest.fn(),
        }}
      >
        <Icon name={ICONS.delete} />
        <span>Delete</span>
      </ConfirmationButton>,
    );
    expect(screen.getByRole("button")).toContainHTML("p-icon--delete");
    expect(screen.getByRole("button")).toContainHTML("<span>Delete</span>");
  });

  it("shows the loading animation when loading is true", () => {
    render(
      <ConfirmationButton
        loading
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm: jest.fn(),
        }}
      />,
    );
    expect(screen.getByRole("button")).toContainHTML(
      "u-animation--spin p-icon--spinner",
    );
  });

  it("shows a customised hover text", () => {
    render(
      <ConfirmationButton
        onHoverText="Delete"
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm: jest.fn(),
        }}
      />,
    );
    expect(screen.getByTitle("Delete")).toBeInTheDocument();
  });

  it("performs the action skipping the confirmation with shift+click when enabled", async () => {
    const onConfirm = jest.fn();
    render(
      <ConfirmationButton
        shiftClickEnabled
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm,
        }}
      />,
    );
    const user = userEvent.setup();
    await user.keyboard("{Shift>}");
    await user.click(screen.getByTitle("Confirm"));
    await user.keyboard("{/Shift}");
    expect(screen.queryByText("Confirm")).not.toBeInTheDocument();
    expect(onConfirm).toHaveBeenCalled();
  });

  it("shows the shift click hint", () => {
    render(
      <ConfirmationButton
        showShiftClickHint
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm: jest.fn(),
        }}
      />,
    );
    const button = screen.getByTitle("Confirm");
    const clickEvent = createEvent.click(button);
    fireEvent(button, clickEvent);
    expect(document.body).toContainHTML("<code>SHIFT</code>");
  });

  it("passes extra classes to the modal wrapper", async () => {
    render(
      <ConfirmationButton
        confirmationModalProps={{
          className: "extra-class",
          confirmButtonLabel: "Confirm",
          onConfirm: jest.fn(),
        }}
      />,
    );
    const button = screen.getByTitle("Confirm");
    const clickEvent = createEvent.click(button);
    fireEvent(button, clickEvent);
    expect(document.body).toContainHTML("p-modal extra-class");
  });

  it("passes extra classes to the button", () => {
    render(
      <ConfirmationButton
        className="extra-class"
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm: jest.fn(),
        }}
      />,
    );
    expect(screen.getByTitle("Confirm")).toHaveClass("extra-class");
  });

  it("does not show the modal if shouldShowModal returns false", () => {
    const shouldShowModal = jest.fn().mockReturnValue(false);
    const onConfirm = jest.fn();

    render(
      <ConfirmationButton
        preModalOpenHook={shouldShowModal}
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm,
        }}
      />,
    );

    const button = screen.getByRole("button");
    fireEvent.click(button);

    expect(shouldShowModal).toHaveBeenCalled();
    expect(screen.queryByText("Confirm")).not.toBeInTheDocument();
    expect(onConfirm).not.toHaveBeenCalled();
  });

  it("shows the modal if shouldShowModal returns true", () => {
    const shouldShowModal = jest.fn().mockReturnValue(true);
    const onConfirm = jest.fn();

    render(
      <ConfirmationButton
        preModalOpenHook={shouldShowModal}
        confirmationModalProps={{
          confirmButtonLabel: "Confirm",
          onConfirm,
        }}
      />,
    );

    const button = screen.getByRole("button");
    fireEvent.click(button);

    expect(shouldShowModal).toHaveBeenCalled();
    expect(screen.getByText("Confirm")).toBeInTheDocument();
  });

  it("executes onConfirm when clicking the modal confirm button", async () => {
    const onConfirm = jest.fn();
    render(
      <ConfirmationButton
        confirmationModalProps={{
          confirmButtonLabel: "Proceed",
          onConfirm,
        }}
      >
        Delete
      </ConfirmationButton>,
    );

    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: "Delete" }));
    await user.click(screen.getByRole("button", { name: "Proceed" }));

    expect(onConfirm).toHaveBeenCalledTimes(1);
  });

  it("ignores portal overrides passed through confirmationModalProps", async () => {
    const onConfirm = jest.fn();
    render(
      <ConfirmationButton
        confirmationModalProps={
          {
            confirmButtonLabel: "Proceed",
            onConfirm,
            renderInPortal: true,
            portalRenderer: ({ children }: { children: React.ReactNode }) => (
              <div data-testid="unsafe-portal">{children}</div>
            ),
          } as unknown as React.ComponentProps<
            typeof ConfirmationButton
          >["confirmationModalProps"]
        }
      >
        Delete
      </ConfirmationButton>,
    );

    const user = userEvent.setup();
    await user.click(screen.getByRole("button", { name: "Delete" }));
    await user.click(screen.getByRole("button", { name: "Proceed" }));

    expect(onConfirm).toHaveBeenCalledTimes(1);
    expect(screen.queryByTestId("unsafe-portal")).not.toBeInTheDocument();
  });
});
